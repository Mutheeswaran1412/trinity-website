// Trinity Technology Solutions - Animations Disabled
// All scroll-triggered animations have been removed for better performance